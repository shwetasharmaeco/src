"""Melon data."""


melons = {
    'Honeydew': {
        'price': 0.99,
        'seedless': True,
        'flesh_color': None,
        'rind_color': None,
        'weight': None,
    },

    'Crenshaw': {
        'price': 2.00,
        'seedless': False,
        'flesh_color': None,
        'rind_color': None,
        'weight': None,
    },

    'Crane': {
        'price': 2.50,
        'seedless': False,
        'flesh_color': None,
        'rind_color': None,
        'weight': None,
    },

    'Casaba': {
        'price': 2.50,
        'seedless': False,
        'flesh_color': None,
        'rind_color': None,
        'weight': None,
    },

    'Cantaloupe': {
        'price': 0.99,
        'seedless': False,
        'flesh_color': None,
        'rind_color': None,
        'weight': None,
    }
}
